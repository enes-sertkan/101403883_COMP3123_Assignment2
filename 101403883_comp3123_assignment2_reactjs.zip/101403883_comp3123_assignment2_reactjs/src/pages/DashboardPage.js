import React, { useEffect, useState, useCallback } from 'react';
import { Link } from 'react-router-dom';
import employeeService from '../services/employeeService';

function DashboardPage() {
    const [employees, setEmployees] = useState([]);

    // Fetch employees function
    const fetchEmployees = useCallback(async () => {
        try {
            const employeeList = await employeeService.getAllEmployees();
            setEmployees(employeeList);
        } catch (error) {
            console.error('Error fetching employees:', error);
        }
    }, []);

    // Fetch employees on mount and after adding a new employee
    useEffect(() => {
        fetchEmployees();
    }, [fetchEmployees]);

    // Function to handle the deletion of an employee
    const handleDelete = async (id) => {
        try {
            await employeeService.deleteEmployee(id);
            // Remove the employee from the local state to update the UI
            setEmployees(employees.filter(employee => employee.id !== id));
        } catch (error) {
            console.error('Error deleting employee:', error);
            // Optionally, handle the display of any error messages here
        }
    };

    return (
        <div className="container">
            <div className="header text-center mb-20">
                <h1>Employees List</h1>
                <Link to="/add-employee" className="btn btn-primary">Add Employee</Link>
            </div>
            <table className="table">
                <thead>
                    <tr>
                        <th>Employee First Name</th>
                        <th>Employee Last Name</th>
                        <th>Employee Email Id</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {employees.map((employee) => (
                        <tr key={employee.id}>
                            <td>{employee.firstName}</td>
                            <td>{employee.lastName}</td>
                            <td>{employee.email}</td>
                            <td>
                                <Link to={`/edit-employee/${employee.id}`} className="btn btn-info">Update</Link>
                                <button onClick={() => handleDelete(employee.id)} className="btn btn-danger">Delete</button>
                                <Link to={`/view-employee/${employee.id}`} className="btn btn-secondary">View</Link>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}

export default DashboardPage;
