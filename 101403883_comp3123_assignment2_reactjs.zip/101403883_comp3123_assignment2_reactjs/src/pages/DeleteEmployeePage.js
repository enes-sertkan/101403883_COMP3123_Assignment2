import React, { useState, useEffect } from 'react';
// Import your employeeService if you have methods to fetch and delete employees
import employeeService from '../services/employeeService';

function DeleteEmployeePage() {
    const [employees, setEmployees] = useState([]);

    useEffect(() => {
        // Fetch the list of employees from your API and set it to state
        // For now, we'll use a static list for demonstration
        setEmployees([
            { id: 1, name: 'John Doe' },
            { id: 2, name: 'Jane Smith' },
            // Add more dummy employees or fetch from your API
        ]);
    }, []);

    const handleDelete = async (employeeId) => {
        try {
            // Call the service method to delete an employee
            await employeeService.deleteEmployee(employeeId);
            console.log('Employee deleted');
            // Update local state to remove the employee from the list, or fetch the updated list
        } catch (error) {
            console.error('There was an error deleting the employee:', error);
            // Handle error feedback to the user
        }
    };


    return (
        <div className="delete-employee-page">
            <h1>Delete Employee</h1>
            <ul>
                {employees.map(employee => (
                    <li key={employee.id}>
                        {employee.name}
                        <button onClick={() => handleDelete(employee.id)}>Delete</button>
                    </li>
                ))}
            </ul>
        </div>
    );
}

export default DeleteEmployeePage;
