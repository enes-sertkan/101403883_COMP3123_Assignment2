import React, { useState } from 'react';
import employeeService from '../services/employeeService';


function AddEmployeePage() {
    const [employee, setEmployee] = useState({
        name: '',
        position: '',
        department: '',
        // Add other employee fields as needed
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setEmployee(prevState => ({
            ...prevState,
            [name]: value
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const addedEmployee = await employeeService.addEmployee(employee);
            // After adding, you can call fetchEmployees from your context or parent component
            // to update the list of employees
        } catch (error) {
            console.error('There was an error adding the employee:', error);
        }
    };



    return (
        <div className="add-employee-page">
            <h1>Add New Employee</h1>
            <form onSubmit={handleSubmit}>
                <div>
                    <label>Name:</label>
                    <input
                        type="text"
                        name="name"
                        value={employee.name}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div>
                    <label>Position:</label>
                    <input
                        type="text"
                        name="position"
                        value={employee.position}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div>
                    <label>Department:</label>
                    <input
                        type="text"
                        name="department"
                        value={employee.department}
                        onChange={handleChange}
                        required
                    />
                </div>
                {/* Add other input fields as needed */}
                <button type="submit">Add Employee</button>
            </form>
        </div>
    );
}

export default AddEmployeePage;
