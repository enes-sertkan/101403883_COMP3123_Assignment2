const API_URL = "http://localhost:3000/api/employees"; // Adjust this URL to match your actual API endpoint

const getAllEmployees = async () => {
    const response = await fetch(API_URL);
    if (!response.ok) {
        throw new Error('Error fetching employees');
    }
    return await response.json();
};

const getEmployeeById = async (id) => {
    const response = await fetch(`${API_URL}/${id}`);
    if (!response.ok) {
        throw new Error(`Error fetching employee with ID ${id}`);
    }
    return await response.json();
};

const addEmployee = async (employeeData) => {
    try {
        const response = await fetch(API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(employeeData)
        });

        if (!response.ok) {
            // Log more details for debugging
            const errorResponse = await response.text();
            console.error('Error response:', errorResponse);
            throw new Error('Error adding new employee');
        }

        return await response.json();
    } catch (error) {
        console.error('Error in addEmployee:', error);
        throw error;
    }
};


const updateEmployee = async (id, employeeData) => {
    const response = await fetch(`${API_URL}/${id}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(employeeData)
    });
    if (!response.ok) {
        throw new Error(`Error updating employee with ID ${id}`);
    }
    return await response.json();
};

const deleteEmployee = async (id) => {
    const response = await fetch(`${API_URL}/${id}`, {
        method: 'DELETE'
    });
    if (!response.ok) {
        throw new Error(`Error deleting employee with ID ${id}`);
    }
    return await response.json();
};

// Export all functions for use in other files
export default {
    getAllEmployees,
    getEmployeeById,
    addEmployee,
    updateEmployee,
    deleteEmployee
};
